"""
Entradas
Capital

Salidas
Ganancia

La razon es un dato conocido, no se toma como entrada
"""
cap=int (input("Ingrese el valor del capital invertido: "))
ganancia=(cap*0.02)
print("La ganancia mensual es de: "+str(ganancia))