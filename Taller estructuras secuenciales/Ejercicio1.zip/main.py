""""
Entradas
edad1
edad2
edad3
salidas
Edad promedio float avg
"""
edad1=int(input("Ingrese la edad 1: "))
edad2=int(input("Ingrese la edad 2: "))
edad3=int(input("Ingrese la edad 3: "))
avg=((edad1+edad2+edad3)/3)
print("La edad promedio es: "+str(avg))